import 'package:flutter/material.dart';
import 'package:netflix/shared/widgets/circImage.dart';
import 'package:netflix/shared/widgets/imageCont.dart';

class MyList extends StatelessWidget {
  const MyList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Text(
            "My List",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 12.0, bottom: 12.0),
          // color: const Color.fromARGB(255, 47, 16, 16),
          height: 50 * 5,
          width: double.infinity,
          // color: Colors.amber[100],
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Row(
                children: [
                  ImageCont(imagePath: "assets/umbrella_academy.jpg"),
                  ImageCont(imagePath: "assets/violet_evergarden.jpg"),
                  ImageCont(imagePath: "assets/thirteen_reasons.jpg"),
                  ImageCont(imagePath: "assets/stranger_things.jpg"),
                  ImageCont(imagePath: "assets/witcher.jpg"),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
