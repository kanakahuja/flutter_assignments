import 'package:flutter/material.dart';

class comingSoonSectionsTitle extends StatelessWidget {
  String? imagePath;
  comingSoonSectionsTitle({
    this.imagePath = "assets/onePieceLogo.png",
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.blue,
      height: MediaQuery.of(context).size.height * 0.085,
      margin: EdgeInsets.only(
        top: MediaQuery.of(context).size.height * 0.025,
      ),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Image.asset(
              imagePath!,
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
            flex: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(
                  Icons.notifications_outlined,
                  size: MediaQuery.of(context).size.height * 0.05,
                  color: Colors.white,
                ),
                Text(
                  "Remind Me",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: MediaQuery.of(context).size.height * 0.02,
                  ),
                )
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(
                  Icons.info_outline,
                  size: MediaQuery.of(context).size.height * 0.05,
                  color: Colors.white,
                ),
                Text(
                  "Info",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: MediaQuery.of(context).size.height * 0.02,
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
