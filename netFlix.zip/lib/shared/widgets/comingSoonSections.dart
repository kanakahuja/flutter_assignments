import 'package:flutter/material.dart';
import 'package:netflix/shared/widgets/comingSoonCategory.dart';
import 'package:netflix/shared/widgets/comingSoonDate.dart';
import 'package:netflix/shared/widgets/comingSoonDescription.dart';
import 'package:netflix/shared/widgets/comingSoonSectionsImage.dart';
import 'package:netflix/shared/widgets/comingSoonSectionsTitle.dart';

class comingSoonSection extends StatelessWidget {
  String? mon;
  int? day;
  String? heroImage;
  String? logoImage;
  String? contentClass;
  String? ageCategory;
  String? desc;
  List<String> category;
  comingSoonSection({
    this.mon = "August",
    this.day = 31,
    this.heroImage = "assets/onePiece.png",
    this.contentClass = "U/A",
    this.ageCategory = "16+",
    this.logoImage = "assets/onePieceLogo.png",
    this.desc =
        "With his straw hat and ragtag crew, young pirate Monky D. Luffy goes on an epic voyage fpr treasure in this live-action adaptation of the popular manga.",
    this.category = const [
      "Rousing",
      "Adventure",
      "Visualy Striking",
      "Pirates"
    ],
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: MediaQuery.of(context).size.height * 0.02,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          comingSoonDate(
            mon: mon!.substring(0, 3),
            day: day,
          ),
          Container(
            width: MediaQuery.of(context).size.width * 5 / 6,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                comingSoonSectionsImage(
                  imagePath: heroImage,
                  ageCategory: ageCategory,
                  contentClass: contentClass,
                ),
                comingSoonSectionsTitle(
                  imagePath: logoImage,
                ),
                comingSoonSectionDescription(
                  date: "$mon $day",
                  desc: desc,
                ),
                comingSoonSectionCategory(
                  category: category,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
