import 'package:flutter/material.dart';

class MyChip extends StatefulWidget {
  String? icon;
  String? title;
  bool selected = true;

  MyChip({
    required this.selected,
    this.icon = "🍟",
    this.title = "Coming Soon",
    super.key,
  });

  @override
  State<MyChip> createState() => _MyChipState();
}

class _MyChipState extends State<MyChip> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          // top: MediaQuery.of(context).size.height * 0.01,
          bottom: MediaQuery.of(context).size.height * 0.003,
          right: MediaQuery.of(context).size.width * 0.04,
          left: MediaQuery.of(context).size.width * 0.025),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: widget.selected ? Colors.white : Colors.black,
      ),
      child: Row(
        children: [
          Center(
            child: Text(
              widget.icon!,
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.height * 0.036,
              ),
            ),
          ),
          Center(
            child: Text(
              " ${widget.title}",
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.height * 0.027,
                color: widget.selected ? Colors.black : Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
