import 'package:flutter/material.dart';
import 'package:netflix/shared/widgets/circImage.dart';

class Preview extends StatelessWidget {
  const Preview({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            top: 8.0,
            left: 8.0,
          ),
          child: Text(
            "Previews",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        Container(
          // color: const Color.fromARGB(255, 47, 16, 16),
          margin: EdgeInsets.only(top: 6.0, bottom: 8.0),
          height: 50 * 2.5,
          width: double.infinity,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              Row(
                children: [
                  CircImage("assets/sintel.jpg"),
                  CircImage("assets/stranger_things.jpg"),
                  CircImage("assets/thirteen_reasons.jpg"),
                  CircImage("assets/witcher.jpg"),
                  CircImage("assets/violet_evergarden.jpg"),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
