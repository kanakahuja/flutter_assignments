import 'package:flutter/material.dart';
import 'package:netflix/screens/homePage.dart';
import 'package:netflix/screens/more.dart';

void main() {
  return runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}
