import 'package:flutter/material.dart';
import 'package:netflix/screens/homePage.dart';
import 'package:netflix/shared/widgets/MoreSectionsTiles.dart';

class More extends StatefulWidget {
  const More({super.key});

  @override
  State<More> createState() => _MoreState();
}

class _MoreState extends State<More> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(46),
          // Take the appbar out and put it in the list to toggle the appbars after assuring its styling and design part
          child: AppBar(
            leading: BackButton(
              onPressed: () {
                Navigator.pushReplacement(
                    context, MaterialPageRoute(builder: (context) => Home()));
              },
            ),
            leadingWidth: 38,
            titleSpacing: 10,
            backgroundColor: Colors.black,
            title: Text(
              "Profiles & More",
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.height * 0.044,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(),
                padding: EdgeInsets.all(4),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.24,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    UserProfile(
                      locked: true,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.024,
                    ),
                    UserProfile(
                      profileImgPath: "assets/profile_babyYoda.png",
                      profileName: "Grogs",
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.024,
                    ),
                    UserProfile(
                      profileImgPath: "assets/profile_GolDRoger.jpg",
                      profileName: "Gold",
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.024,
                    ),
                    UserProfile(
                      profileImgPath: "assets/profile_grumpyHen.png",
                      profileName: "Henry",
                      locked: true,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.024,
                    ),
                    UserProfile(
                      profileImgPath: "assets/profile_professor.jfif",
                      profileName: "Álvaro",
                      locked: true,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.02,
              ),
              GestureDetector(
                onTap: () {},
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.edit_outlined,
                      color: Colors.grey,
                      size: MediaQuery.of(context).size.height * 0.04,
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.018,
                    ),
                    Text(
                      "Manage Profiles",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: MediaQuery.of(context).size.height * 0.03,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.04,
              ),
              Container(
                // decoration: BoxDecoration(
                //   color: Colors.amber[50],
                // ),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.6,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    MoreSectionListTiles(),
                    MoreSectionListTiles(
                      title: "My List",
                      leadingIcon: Icons.format_list_bulleted_rounded,
                    ),
                    MoreSectionListTiles(
                      title: "App Settings",
                      leadingIcon: Icons.settings_outlined,
                    ),
                    MoreSectionListTiles(
                      title: "Account",
                      leadingIcon: Icons.person,
                    ),
                    MoreSectionListTiles(
                      title: "Help",
                      leadingIcon: Icons.help_outline_rounded,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.04,
              ),
              GestureDetector(
                onTap: () {},
                child: Text(
                  "Sign Out",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: MediaQuery.of(context).size.height * 0.03,
                  ),
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.06,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class UserProfile extends StatelessWidget {
  String? profileImgPath;
  String? profileName;
  bool? locked;
  UserProfile({
    this.profileImgPath = "assets/profile_AllMight.jpg",
    this.profileName = "Toshi",
    this.locked = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: Image(
            image: AssetImage(profileImgPath!),
            fit: BoxFit.contain,
            height: MediaQuery.of(context).size.height * 0.14,
            width: MediaQuery.of(context).size.height * 0.14,
          ),
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.01,
        ),
        Text(
          profileName!,
          style: TextStyle(
            color: Colors.white,
            fontSize: MediaQuery.of(context).size.height * 0.03,
            fontWeight: FontWeight.bold,
          ),
        ),
        Icon(
          locked! ? Icons.lock_outline : null,
          size: MediaQuery.of(context).size.height * 0.03,
          color: Colors.white,
        )
      ],
    );
  }
}
