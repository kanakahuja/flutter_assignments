import 'package:flutter/material.dart';
import 'package:netflix/shared/widgets/IndianMovies.dart';
import 'package:netflix/shared/widgets/myList.dart';
import 'package:netflix/shared/widgets/nsStack.dart';
import 'package:netflix/shared/widgets/originals.dart';
import 'package:netflix/shared/widgets/preview.dart';
import 'package:netflix/shared/widgets/toggleAppbar.dart';
import 'package:netflix/shared/widgets/togglePage.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currInd = 0;
  // List screens = [
  //   SingleChildScrollView(
  //     child: Container(
  //       color: Colors.black,
  //       width: double.infinity,
  //       // height: double.infinity,
  //       child: const Column(
  //         children: [
  //           MyStack(),
  //           Preview(),
  //           MyList(),
  //           Originals(),
  //           Indian(),
  //         ],
  //       ),
  //     ),
  //   ),
  //   Text(
  //     "Search",
  //     style: TextStyle(
  //         color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
  //   ),
  //   Text(
  //     "Coming Soon",
  //     style: TextStyle(
  //         color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
  //   ),
  //   Text(
  //     "Downloads",
  //     style: TextStyle(
  //         color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
  //   ),
  //   Text(
  //     "More",
  //     style: TextStyle(
  //         color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
  //   )
  // ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true, //for transparency ;
          appBar: _currInd == 0
              ? PreferredSize(
                  preferredSize:
                      Size.fromHeight(MediaQuery.of(context).size.height * 0.1),
                  child: AppBar(
                    backgroundColor: Colors.transparent,
                    leading: Image.asset(
                      "assets/logo.png",
                    ),
                    actions: [
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 16.0, bottom: 16.0, right: 8.0, left: 8.0),
                        child: GestureDetector(
                          onTap: () {},
                          child: const Text(
                            "TV Shows",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(
                            top: 16.0, bottom: 16.0, right: 8.0, left: 8.0),
                        child: Text(
                          "Movies",
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      //
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 8.0, bottom: 13.0, left: 0, right: 0),
                        child: OutlinedButton(
                          onPressed: () {},
                          child: const Text(
                            "My List",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : null,
          // body: screens[_currInd],

          // creating a widget for page toggling may be an overkill
          body: TogglePage(
            currInd: _currInd,
          ),

          // bottomNavigationBar
          // jab in icons pe tap krein toh nya page pe direct krde
          // use function ontapped
          // has a list of screens and use index to direct to page as per the tapped icon
          //////////////////////

          bottomNavigationBar: _currInd == 4
              ? null
              : BottomNavigationBar(
                  // List screens = [home(), aboutUs(), contact()],
                  // and  now use onTapped()
                  currentIndex: _currInd,
                  type: BottomNavigationBarType.fixed,
                  backgroundColor: Colors.black,
                  selectedItemColor: Colors.white,
                  unselectedItemColor: Colors.grey,
                  items: [
                    BottomNavigationBarItem(
                      label: "Home",
                      icon: Icon(Icons.home),
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.queue_play_next_sharp),
                      label: "Coming Soon",
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.download_sharp),
                      label: "Download",
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.more_vert_rounded),
                      label: "More",
                    ),
                  ],

                  // using onTapped
                  onTap: (i) {
                    setState(() {
                      _currInd = i;
                    });
                  },
                )),
    );
  }
}
